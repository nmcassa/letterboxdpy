# letterboxdpy
A letterboxd python webscraper that can return json information about users

hopefully more in the future...

![Example of the webscraper](example.PNG)
