# letterboxdpy

A letterboxd python webscraper that can return json information about users and movies

hopefully more in the future...

## **Example of Movie Object**

![Example of the movie object](ss/movie_example.PNG)

## **Example of User Object**

![Example of the user object](ss/user_example.PNG)

### **Code used for above**

![Example code](ss/code_example.PNG)